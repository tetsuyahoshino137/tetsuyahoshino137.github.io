#!/usr/bin/env python3
"""Redraw the paper's numerical figures or rerun its estimation experiments.

Default: redraw Figures 3 and 4 from the archived results, without a GPU.
Estimation is opt-in. Original class bodies are in code/original_model.py.
Each invocation creates a fresh output directory and preserves the inputs.
"""
import argparse
import contextlib
import hashlib
import json
import os
import platform
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = {
    '3': {'n': 11, 'observations': 100000, 'methods': ['maximum_likelihood', 'contrastive_divergence'],
          'data': 'data/figure3/synthetic_data_N11x11_D100000_B1000.json',
          'results': ['results/figure3/training_data_N11x11_D100000_B1000_cd.json',
                      'results/figure3/training_data_N11x11_D100000_B1000_ml.json']},
    '4': {'n': 15, 'observations': 500000, 'methods': ['contrastive_divergence'],
          'data': 'data/figure4/synthetic_data_N15x15_D500000_B1000.json',
          'results': ['results/figure4/training_data_N15x15_D500000_B1000_T7200_cd.json']},
}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')


class Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, text):
        for stream in self.streams:
            stream.write(text)
        return len(text)

    def flush(self):
        for stream in self.streams:
            stream.flush()


def redraw(paths, figure, destination):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.ticker import FixedFormatter, FixedLocator, LogLocator

    plt.rcParams.update({'text.usetex': False, 'font.family': 'DejaVu Serif'})
    fig, ax = plt.subplots(figsize=(14.562, 9))
    all_errors = []
    for path in paths:
        result = json.loads(Path(path).read_text())
        times = [entry['time'] for entry in result['losses']]
        errors = [entry['mse_Wb'] for entry in result['losses']]
        method = result['train_parameters']['training_method']
        cd = method == 'contrastive_divergence'
        ax.plot(times, errors, linestyle='-' if cd else '--',
                color='blue' if cd else 'red', linewidth=3,
                label='Contrastive Divergence' if cd else 'Maximum Likelihood')
        all_errors.extend(errors)
        print(f'Figure {figure}: {Path(path).name}; {len(errors)} points; final MSE={errors[-1]:.12g}')
    ax.legend(fontsize=28, frameon=False, loc='upper right')
    ax.set_xlabel('Time (minutes)', fontsize=32)
    ax.set_ylabel('Mean Squared Error', fontsize=32)
    max_seconds = max(json.loads(Path(p).read_text())['train_parameters']['time_limit'] for p in paths)
    # The saved time values are seconds; the displayed tick labels are minutes.
    if max_seconds >= 1800:
        minutes = list(range(0, int(max_seconds // 60) + 1, 30))
        ax.set_xticks([m * 60 for m in minutes], labels=[str(m) for m in minutes])
    else:
        from matplotlib.ticker import FuncFormatter
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f'{x/60:g}'))
    ax.set_yscale('log')
    ax.set_ylim(min(all_errors) * 0.9, max(all_errors) * 1.2)
    ax.yaxis.set_major_locator(FixedLocator([0.01, 0.1, 0.5, 1]))
    ax.yaxis.set_major_formatter(FixedFormatter(['0.01', '0.1', '0.5', '1']))
    ax.yaxis.set_minor_locator(LogLocator(base=10, subs=np.arange(2, 10) * 0.1, numticks=10))
    ax.tick_params(axis='y', which='minor', labelleft=False)
    ax.tick_params(axis='both', which='major', labelsize=28)
    for suffix in ['pdf', 'png']:
        fig.savefig(destination / f'Figure_{figure}.{suffix}', bbox_inches='tight', dpi=180)
    plt.close(fig)


def model_module(device):
    sys.path.insert(0, str(ROOT / 'code'))
    import original_model as model
    import torch
    if device == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA GPU unavailable. Select a GPU runtime for estimation, or explicitly use --device cpu.')
    model.device = torch.device(device)
    return model


def configure(model, n, observations, seed, seconds):
    import torch
    config = model.Config()
    config.n1 = config.n2 = n
    config.data_size = observations
    config.time_limit = seconds
    config.set_rand_seed(seed)
    # Preserve the original CPU draw followed by device transfer.
    config.true_W = torch.randn(n, n).to(model.device)
    config.true_b1 = torch.randn(n).to(model.device)
    config.true_b2 = torch.randn(n).to(model.device)
    config.data_filename = f'synthetic_data_N{n}x{n}_D{observations}_B{config.batch_size}.json'
    return config


def estimate(case, figure, args, destination):
    import torch
    from torch.utils.data import DataLoader, TensorDataset
    model = model_module(args.device)
    config = configure(model, case['n'], case['observations'], args.seed, args.time_limit)
    config.training_methods = case['methods']
    network = model.RBM(config)  # Original notebook initializes this before generating data.
    if args.data_source == 'generate':
        data1, data2 = model.MyDataset(config).generate_data()
        synthetic = {
            'data_parameters': {'n1': config.n1, 'n2': config.n2, 'data_size': config.data_size, 'gibbs_step': config.gibbs_step},
            'true_parameters': {k: getattr(config, f'true_{k}').cpu().tolist() for k in ['W', 'b1', 'b2']},
            'data1': data1.cpu().tolist(), 'data2': data2.cpu().tolist(),
        }
        save_json(destination / config.data_filename, synthetic)
        del synthetic
    else:
        data1, data2, true = model.MyDataset.load_data(str(ROOT / case['data']), config)
        # Use the archived truth for the MSE rather than silently regenerating it.
        for key, value in true.items():
            setattr(config, f'true_{key}', value)
    digest = hashlib.sha256(data1.cpu().numpy().tobytes() + data2.cpu().numpy().tobytes()).hexdigest()
    save_json(destination / 'input_provenance.json', {
        'data_source': args.data_source, 'observations_float32_sha256': digest,
        'archived_input_file': case['data'], 'archived_input_file_sha256': sha256(ROOT / case['data']),
        'seed': args.seed,
    })
    loader = DataLoader(TensorDataset(data1, data2), batch_size=config.batch_size, shuffle=True)
    trainer = model.Trainer(config, network, loader)
    result_paths = []
    for method in config.training_methods:
        print(f'Figure {figure}: running {method}; time limit {config.time_limit} seconds per method', flush=True)
        _, losses = trainer.train(method, 0.1)
        result = {
            'data_parameters': {'n1': config.n1, 'n2': config.n2, 'data_size': config.data_size, 'batch_size': config.batch_size},
            'train_parameters': {'training_method': method, 'time_limit': config.time_limit, 'cd_step': config.cd_step},
            'learning_rate': 0.1, 'losses': losses,
        }
        target = destination / config.get_results_filename(method)
        save_json(target, result)
        result_paths.append(target)
    redraw(result_paths, figure, destination)


def check_small_model(destination):
    """Exercise both original training paths cheaply; not a paper replication."""
    import torch
    from torch.utils.data import DataLoader, TensorDataset
    model = model_module('cpu')
    torch.set_num_threads(2)
    config = configure(model, 2, 128, 42, 0.01)
    config.batch_size = 64
    config.gibbs_step = 20
    network = model.RBM(config)
    data1, data2 = model.MyDataset(config).generate_data()
    trainer = model.Trainer(config, network, DataLoader(TensorDataset(data1, data2), batch_size=64, shuffle=True))
    traces = {}
    for method in ['maximum_likelihood', 'contrastive_divergence']:
        _, losses = trainer.train(method, 0.1)
        assert len(losses) >= 2
        assert all(torch.isfinite(torch.tensor(p['mse_Wb'])) for p in losses)
        traces[method] = losses
    save_json(destination / 'small_model_check.json', traces)
    print('Small-model check passed for both ML and CD. This is not the full paper experiment.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['redraw', 'estimate', 'check'], default='redraw')
    parser.add_argument('--figure', choices=['3', '4', 'all'], default='all')
    parser.add_argument('--device', choices=['cuda', 'cpu'], default='cuda')
    parser.add_argument('--data-source', choices=['generate', 'archived'], default='generate')
    parser.add_argument('--time-limit', type=float, default=7200)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--output-dir', type=Path)
    args = parser.parse_args()
    if args.time_limit <= 0:
        parser.error('--time-limit must be positive')
    destination = args.output_dir or ROOT / 'outputs' / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8])
    destination = destination.resolve()
    for protected in ['data', 'results', 'code', 'original_figures', 'verification']:
        if destination.is_relative_to(ROOT / protected):
            parser.error('The output directory must not be inside an input directory.')
    destination.mkdir(parents=True, exist_ok=False)
    os.environ.setdefault('MPLCONFIGDIR', str(destination / '.matplotlib_cache'))
    started = time.perf_counter()
    with (destination / 'run.log').open('w') as log:
        with contextlib.redirect_stdout(Tee(sys.stdout, log)), contextlib.redirect_stderr(Tee(sys.stderr, log)):
            metadata = {'python': platform.python_version(), 'platform': platform.platform(),
                        'mode': args.mode, 'figure': args.figure, 'time_limit_per_method': args.time_limit,
                        'seed': args.seed, 'data_source': args.data_source,
                        'master_script_sha256': sha256(__file__)}
            import matplotlib
            import numpy as np
            metadata.update({'numpy': np.__version__, 'matplotlib': matplotlib.__version__})
            if args.mode != 'redraw':
                import torch
                import tqdm
                metadata.update({'torch': torch.__version__, 'cuda': torch.version.cuda,
                                 'tqdm': tqdm.__version__, 'device': 'cpu' if args.mode == 'check' else args.device,
                                 'gpu': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None})
            save_json(destination / 'environment.json', metadata)
            if args.mode == 'check':
                check_small_model(destination)
            else:
                for figure in (['3', '4'] if args.figure == 'all' else [args.figure]):
                    case = CASES[figure]
                    if args.mode == 'redraw':
                        redraw([ROOT / p for p in case['results']], figure, destination)
                    else:
                        figure_output = destination / f'figure{figure}'
                        figure_output.mkdir()
                        estimate(case, figure, args, figure_output)
            metadata.update({'completed': True, 'elapsed_seconds': time.perf_counter() - started})
            save_json(destination / 'environment.json', metadata)
            print(f'Completed in {metadata["elapsed_seconds"]:.2f} seconds. Outputs: {destination.name}')


if __name__ == '__main__':
    main()
