"""Original notebook class bodies, extracted without changing their algorithms.

Only imports, device selection, and a local replacement for Colab's download
notification are added. Use run_all.py as the entry point. See README.rtf, Section 5.
"""
import itertools
import json
import random
import time
import numpy as np
from tqdm.auto import tqdm
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class _LocalFiles:
    @staticmethod
    def download(filename):
        print(f"Saved locally: {filename}")

files = _LocalFiles()

class Config:
    def __init__(self):
        # RBM parameters
        self.n1 = 11  # Number of nodes on layer 1
        self.n2 = 11  # Number of nodes on layer 2

        self.set_rand_seed()
        self.true_W = torch.randn(self.n1, self.n2).to(device)
        self.true_b1 = torch.randn(self.n1).to(device)
        self.true_b2 = torch.randn(self.n2).to(device)

        # Data generation parameters
        self.data_size = 100_000
        self.batch_size = 1_000
        self.gibbs_step = 500

        # Training parameters
        self.time_limit = 7200  # in seconds
        self.cd_step = 1 # only for Contrastive Divergence

        # Learning rates
        self.learning_rates = [0.1]

        # Training methods
        self.training_methods = ['maximum_likelihood', 'contrastive_divergence']

        # File name
        self.data_filename = f"synthetic_data_N{self.n1}x{self.n2}_D{self.data_size}_B{self.batch_size}.json"

    def get_results_filename(self, training_method):
        training_method_abbr = 'cd' if training_method == 'contrastive_divergence' else 'ml'
        return f"training_data_N{self.n1}x{self.n2}_D{self.data_size}_B{self.batch_size}_{training_method_abbr}.json"

    @staticmethod
    def set_rand_seed(seed=42):
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        np.random.seed(seed)
        random.seed(seed)

class RBM(nn.Module):
    def __init__(self, config):
        super(RBM, self).__init__()
        self.config = config
        self.n1 = config.n1  # Number of nodes on layer 1
        self.n2 = config.n2  # Number of nodes on layer 2

        self.cd_step = config.cd_step  # Number of steps in contrastive divergence

        # Initialize model parameters
        self.W = nn.Parameter(torch.randn(self.n1, self.n2).to(device))  # Weight matrix
        self.b1 = nn.Parameter(torch.randn(self.n1).to(device))  # Bias for layer 1
        self.b2 = nn.Parameter(torch.randn(self.n2).to(device))  # Bias for layer 2

    def maximum_likelihood(self, data1, data2):
        """Perform maximum likelihood estimation."""
        # Positive phase
        positive_phase = data1.T @ data2

        # Generate all possible binary states
        self.states1 = torch.tensor(list(itertools.product([0, 1], repeat=self.n1)), dtype=torch.float).to(device)
        self.states2 = torch.tensor(list(itertools.product([0, 1], repeat=self.n2)), dtype=torch.float).to(device)

        # Prepare tensors for efficient computation
        states1_expanded = self.states1.unsqueeze(2).expand(-1, -1, self.n2).unsqueeze(1)
        states2_expanded = self.states2.unsqueeze(1).expand(-1, self.n1, -1).unsqueeze(0)
        self.all_states = (states1_expanded * states2_expanded).reshape(-1, self.n1, self.n2)

        # Compute energies for all states
        all_W_contributions = torch.einsum('bij,ij->bij', self.all_states, self.W)
        all_b1_contributions = torch.repeat_interleave(torch.einsum('bi,i->bi', self.states1, self.b1), self.states2.shape[0], dim=0)
        all_b2_contributions = torch.einsum('bj,j->bj', self.states2, self.b2).repeat(self.states1.shape[0], 1)
        energies = -(torch.sum(all_W_contributions, (1, 2)) + torch.sum(all_b1_contributions, 1) + torch.sum(all_b2_contributions, 1))

        # Compute the partition function
        probabilities = torch.exp(-energies)
        partition_function = probabilities.sum()

        # Compute expectations
        expected_W_products = torch.mul(probabilities[:, None, None].expand(-1, self.W.shape[0], self.W.shape[1]), self.all_states)
        expected_b1_activations = torch.mul(probabilities[:, None].expand(-1, self.W.shape[0]), torch.repeat_interleave(self.states1, self.states2.shape[0], dim=0))
        expected_b2_activations = torch.mul(probabilities[:, None].expand(-1, self.W.shape[1]), self.states2.repeat(self.states1.shape[0], 1))

        negative_phase = expected_W_products.sum(0) / partition_function
        expected_data1 = expected_b1_activations.sum(0) / partition_function
        expected_data2 = expected_b2_activations.sum(0) / partition_function

        # Compute gradients
        self.W.grad = -(positive_phase / len(data1) - negative_phase)
        self.b1.grad = -torch.mean(data1 - expected_data1.squeeze(), dim=0)
        self.b2.grad = -torch.mean(data2 - expected_data2.squeeze(), dim=0)

    def contrastive_divergence(self, data1, data2):
        """Perform contrastive divergence."""
        # Positive phase
        positive_phase = data1.T @ data2

        # Negative phase
        new_data1, new_data2 = self.perform_gibbs_sampling(data2.clone())
        negative_phase = new_data1.T @ new_data2

        # Compute gradients
        self.W.grad = -(positive_phase - negative_phase) / len(data1)
        self.b1.grad = -torch.mean(data1 - new_data1, dim=0)
        self.b2.grad = -torch.mean(data2 - new_data2, dim=0)

    def perform_gibbs_sampling(self, data2):
        """Perform Gibbs sampling."""
        with torch.no_grad():
            for _ in range(self.cd_step):
                data1 = torch.bernoulli(torch.sigmoid(data2 @ self.W.T + self.b1))
                data2 = torch.bernoulli(torch.sigmoid(data1 @ self.W + self.b2))

        return data1, data2

class MyDataset:
    def __init__(self, config):
        self.config = config

        self.data_size = config.data_size
        self.gibbs_step = config.gibbs_step

        self.true_W  = config.true_W
        self.true_b1 = config.true_b1
        self.true_b2 = config.true_b2

    def generate_data(self):
        """Generate synthetic data using Gibbs sampling."""
        # Initialize random data
        data1 = torch.bernoulli(torch.rand(self.data_size, self.config.n1)).to(device)
        data2 = torch.zeros(self.data_size, self.config.n2).to(device)

        # Perform Gibbs sampling
        for _ in tqdm(range(self.gibbs_step), desc='Generating data', leave=True):
            data2 = torch.bernoulli(torch.sigmoid(data1 @ self.true_W + self.true_b2))
            data1 = torch.bernoulli(torch.sigmoid(data2 @ self.true_W.T + self.true_b1))

        return data1, data2

    def save_data(self, data1, data2, filename):
        """Save generated data to a file."""
        print(f"Saving data to {filename}")

        data_to_save = {
            "data_parameters": {
                "n1" : self.config.n1,
                "n2" : self.config.n2,
                "data_size" : self.data_size,
                "gibbs_step" : self.gibbs_step
            },
            "true_parameters": {
                "W"  : self.true_W.cpu().tolist(),
                "b1" : self.true_b1.cpu().tolist(),
                "b2" : self.true_b2.cpu().tolist()
            },
            "data1" : data1.cpu().tolist(),
            "data2" : data2.cpu().tolist()
        }

        with open(filename, 'w') as f:
            json.dump(data_to_save, f)

        print(f"Data saved to {filename}")
        files.download(filename)

    @staticmethod
    def load_data(filename, config):
        """Load data from a file."""
        print(f"Loading data from {filename}")

        with open(filename, 'r') as f:
            loaded_data = json.load(f)

        data1 = torch.tensor(loaded_data['data1']).to(device)
        data2 = torch.tensor(loaded_data['data2']).to(device)

        loaded_true_params = {k: torch.tensor(v).to(device) for k, v in loaded_data['true_parameters'].items()}

        return data1, data2, loaded_true_params

class Trainer:
    def __init__(self, config, model, dataloader):
        self.config = config
        self.model = model

        self.dataloader = dataloader

        self.initial_params = None

    def compute_loss(self):
        """Compute Mean Squared Error between true and estimated parameters."""
        def compute_mse(a, b):
            return ((a - b) ** 2).mean().item()

        model_params = {
            'W'  : self.model.W.detach().cpu(),
            'b1' : self.model.b1.detach().cpu(),
            'b2' : self.model.b2.detach().cpu()
        }

        losses = {
            f'mse_{name}': compute_mse(getattr(self.config, f'true_{name}').cpu(), model_params[name])
            for name in ['W', 'b1', 'b2']
        }

        all_true = torch.cat([getattr(self.config, f'true_{name}').cpu().flatten() for name in ['W', 'b1', 'b2']])
        all_model = torch.cat([p.flatten() for p in model_params.values()])
        losses['mse_Wb'] = compute_mse(all_true, all_model)

        return losses

    def save_initial_params(self):
        """Save the initial parameters of the model."""
        self.initial_params = {
            'W'  : self.model.W.clone().detach(),
            'b1' : self.model.b1.clone().detach(),
            'b2' : self.model.b2.clone().detach()
        }

    def reset_to_initial_params(self):
        """Reset the model to the initial parameters."""
        with torch.no_grad():
            self.model.W.copy_(self.initial_params['W'])
            self.model.b1.copy_(self.initial_params['b1'])
            self.model.b2.copy_(self.initial_params['b2'])

    def train(self, training_method, learning_rate):
        """Train the RBM model."""
        self.model.train()

        # Reset to initial parameters
        if self.initial_params is None:
            self.save_initial_params()
        else:
            self.reset_to_initial_params()

        # Set up optimizer with the current learning rate
        optimizer = optim.SGD(self.model.parameters(), lr=learning_rate)

        losses = []

        # Record initial loss
        initial_loss = self.compute_loss()
        initial_loss.update({'time': 0, 'epoch': 0, 'avg_epoch_loss': initial_loss['mse_Wb']})
        losses.append(initial_loss)

        start_time = time.time()
        epoch = 0

        while time.time() - start_time < self.config.time_limit:
            epoch_loss = 0
            for data1, data2 in tqdm(self.dataloader, desc=f'Epoch {epoch + 1}', leave=False):
                data1, data2 = data1.to(device), data2.to(device)
                optimizer.zero_grad()
                if training_method == 'contrastive_divergence':
                    self.model.contrastive_divergence(data1, data2)
                elif training_method == 'maximum_likelihood':
                    self.model.maximum_likelihood(data1, data2)
                optimizer.step()

                batch_loss = self.compute_loss()
                epoch_loss += batch_loss['mse_Wb']

            avg_epoch_loss = epoch_loss / len(self.dataloader)

            loss = self.compute_loss()
            loss.update({
                'learning_rate'  : optimizer.param_groups[0]['lr'],
                'time'           : time.time() - start_time,
                'epoch'          : epoch + 1,
                'avg_epoch_loss' : avg_epoch_loss
            })
            losses.append(loss)

            # Report training progress
            print(f"Epoch {epoch + 1}: Average loss = {avg_epoch_loss:.6f}, Time elapsed: {time.time() - start_time:.2f} seconds")

            epoch += 1

        return {"score": avg_epoch_loss}, losses

    def save_results(self, training_method, learning_rate, losses):
        """Save training results to a file."""
        results_filename = self.config.get_results_filename(training_method)

        results_to_save = {
            "data_parameters": {
                "n1" : self.config.n1,
                "n2" : self.config.n2,
                "data_size" : self.config.data_size,
                "batch_size" : self.config.batch_size
            },
            "train_parameters": {
                "training_method" : training_method,
                "time_limit" : self.config.time_limit,
                "cd_step" : self.config.cd_step
            },
            "learning_rate" : learning_rate,
            "losses" : losses
        }

        with open(results_filename, 'w') as f:
            json.dump(results_to_save, f, indent=2)

        files.download(results_filename)
        print(f"Training results saved and downloaded: {results_filename}")
